// myls.h
#ifndef MYLS_H
#define MYLS_H

void myls_command();

#endif
