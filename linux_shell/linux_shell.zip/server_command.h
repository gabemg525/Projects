#ifndef SERVER_COMMAND_H
#define SERVER_COMMAND_H

void server_command(char **args);

#endif // SERVER_COMMAND_H
