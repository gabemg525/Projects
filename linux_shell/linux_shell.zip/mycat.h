// mycat.h
#ifndef MYCAT_H
#define MYCAT_H

void mycat_command(char **args);

#endif
